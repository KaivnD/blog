"""
@file building.py
"""
class Floor:
    def __init__(self, name, height, bound):
        self.name = name
        self.height = height
        self.bound = bound

    def __str__(self) -> str:
        return "{}       {}     {:.2f}".format(self.name, self.height, self.bound.area)


class Building:
    def __init__(self, name, buildingt_type):
        self.name = name
        self.type = buildingt_type
        self.floors = []

    def __str__(self) -> str:
        levels = "\n-------------------------\n".join([str(floor) for floor in self.floors])
        return """-------------------------
建筑名称：{}
建筑类型：{}
建筑高度：{} m
建筑层数：{} 层
建筑面积：{:.2f} m²

楼层    层高    面积
-------------------------
{}
-------------------------""".format(self.name, self.type, self.height, len(self.floors), self.area, levels)

    """
    使用跟简洁的写法来求总楼高，sum函数可以对数组进行求和。
    这个只包含楼层高度的数组的写法，详见3.2.2 遍历列表的扩展内容。
    """
    @property
    def height(self):
        return sum([floor.height for floor in self.floors])

    @property
    def area(self):
        return sum([floor.bound.area for floor in self.floors])