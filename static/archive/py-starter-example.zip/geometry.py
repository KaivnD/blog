"""
@file geometry.py
"""
class Polyline2d:
    """
    构造一个多边形，包含一个pts属性，用于储存多边形的各个顶点
    """
    def __init__(self):
        self.pts = []

    """
    add 方法传入两个值，一个x坐标，一个y坐标
    """
    def add(self, x, y):
        # 用元组的形式，把x坐标和y坐标打包成一个数据，储存到self.pts属性内
        self.pts.append((x, y))

    """
    鞋带公式求解已知多边形所有顶点的情况的多边形面积，详见https://www.101computing.net/the-shoelace-algorithm/
    """
    @property
    def area(self):
        s1 = 0
        s2 = 0
        cnt = len(self.pts)

        for i in range(cnt - 1):
            s1 += self.pts[i][0] * self.pts[i+1][1]
            s2 += self.pts[i][1] * self.pts[i+1][0]

        s1 += self.pts[cnt-1][0] * self.pts[0][1]
        s2 += self.pts[0][0] * self.pts[cnt-1][1]

        return abs(s1 - s2) / 2