"""
@file main.py
"""
from geometry import Polyline2d
from building import Floor, Building

# 假设我们有这一组顶点，作为楼层的形状多边形的顶点。
pts = [
    (8.1, -9.483704),
    (8.1, -11.378272),
    (-8.1, -11.378272),
    (-8.1, -9.483704),
    (-16.2, -9.483704),
    (-16.2, 1.67),
    (-6.8, 1.67),
    (-6.8, 3.4),
    (-1.5, 3.4),
    (-1.5, -1.8),
    (1.5, -1.8),
    (1.5, 3.4),
    (6.8, 3.4),
    (6.8, 1.67),
    (16.2, 1.67),
    (16.2, -9.483704),
    (8.1, -9.483704),
    (8.1, -9.483704)
]

# 创建一个多边形
pl = Polyline2d()

# 把顶点数组的所有顶点添加到多边形中
for x, y in pts:
    pl.add(x, y)

# 创建一个建筑实例
building = Building("xx大楼", "公建")

# 楼层信息
floor_heights = [4.5, 3, 3, 4.8, 3, 3]

# 一次性创建6个一样的楼层
for i, height in enumerate(floor_heights):
    floor = Floor("F{}".format(i + 1), height, pl)
    building.floors.append(floor)

print(building)